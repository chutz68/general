package ch.softhenge.supren.exif.common.tag;

public abstract class AbstractTag {

	public abstract String getString();
	
	
	
}
