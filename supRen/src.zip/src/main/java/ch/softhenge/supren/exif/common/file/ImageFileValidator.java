package ch.softhenge.supren.exif.common.file;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ImageFileValidator {

	private Pattern pattern;
	private Matcher matcher;

	private static final String IMAGE_PATTERN = "([^\\s]+(\\.(?i)(jpg|png|gif|bmp|cr2))$)";

	public ImageFileValidator() {
		pattern = Pattern.compile(IMAGE_PATTERN);
	}

	/**
	 * Validate image with regular expression
	 * 
	 * @param imageFileName
	 * @return true valid image, false invalid image
	 */
	public boolean validate(final String imageFileName) {
		matcher = pattern.matcher(imageFileName);
		return matcher.matches();
	}

}
