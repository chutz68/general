package ch.softhenge.supren.exif.common.file;

import static org.junit.Assert.*;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import ch.softhenge.supren.exif.common.TestFile;

public class ImageFileValidatorTest {

	@Test
	public void testFilesCheck() {
		ImageFileValidator fileVal = new ImageFileValidator();
		for (TestFile testFile : TestFile.values()) {
			boolean validImage = fileVal.validate(testFile.getFileName());
			assertThat(true, CoreMatchers.is(validImage));
		}
	}

}
